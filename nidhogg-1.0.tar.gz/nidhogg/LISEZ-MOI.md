Installer :

sudo ./installer.sh

Amusez-vous bien !
